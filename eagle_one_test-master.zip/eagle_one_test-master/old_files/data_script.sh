rosservice call /ardrone/togglecam &

./hud.py &

./hud.py
