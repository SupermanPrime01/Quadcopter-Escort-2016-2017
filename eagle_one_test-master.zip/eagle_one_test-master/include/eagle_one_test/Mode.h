enum class Mode : int
{
    secure      = 0,
    takeoff     = 1,
    flight      = 2,
    land        = 3
};
